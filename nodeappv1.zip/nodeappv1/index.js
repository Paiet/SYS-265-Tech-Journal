console.log('Running on NodeJS!');
